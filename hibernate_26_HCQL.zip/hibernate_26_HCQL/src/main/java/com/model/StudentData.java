package com.model;

public class StudentData {

}
